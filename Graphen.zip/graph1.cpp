

int LoadGraph(istream &is, Graph &G)
{
    int error =0;
    char c;
    int intvalue,vertex,edge;
    string tempstring;

    // Erste Zeile: G (Knotenzahl)
    c=is.get();
    if (c!='G') error=10;
    if (error==0){
        is>>intvalue;
        if (is.bad()) error=21;
        else if (intvalue<1) error=22;
        else if (intvalue>MAX_KNOTEN) error=23;
        else G.knotenzahl=intvalue;
    }
    while (error==0 && c!=EOF)
    {
        c=is.get();
        switch (c){
        case 'V':
            is>>intvalue;
            if (is.bad()) error=31;
            if (error==0)
            {
                c=is.get();
                getline(is,tempstring);
                if (intvalue>0 && intvalue<=MAX_KNOTEN)
                {
                    vertex=intvalue;
                    size_t firstQuote=tempstring.find_first_of("\"",0);
                    size_t lastQuote=tempstring.find_last_of("\"",tempstring.size());
                    if ((firstQuote!=string::npos) && (lastQuote!=string::npos))
                    {
                        tempstring=tempstring.substr(firstQuote+1,lastQuote-1);
                    }
                    G.V[vertex].name=tempstring;
                }
            }
            break;
        case 'E':
            is>>intvalue;
            if (is.bad()) error=41;
            if (error==0){
                vertex=intvalue;
                is>>intvalue;
                if (is.bad()) error=42;
            }
            if (error==0){
                edge=intvalue;
                is>>intvalue;
                if (is.bad()) error=43;
            }
            if (error==0){
                G.Adj[vertex][edge]=intvalue;
            }
            break;
        case ' ': break;
        case '\n': break;
        case '\r': break;
        case '\t': break;
        }
    }
    return error;
}
